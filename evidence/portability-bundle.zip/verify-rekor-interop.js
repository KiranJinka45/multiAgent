// scripts/verify-rekor-interop.ts
import * as crypto from "crypto";
import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";
var REKOR_API_URL = "https://rekor.sigstore.dev/api/v1/log/entries";
var EVIDENCE_FILE = path.join(process.cwd(), "evidence", "rekor-interop-evidence.json");
async function submitMode() {
  console.log("\u{1F680} Starting Rekor live submission mode...");
  const { publicKey, privateKey } = crypto.generateKeyPairSync("ec", {
    namedCurve: "P-256",
    publicKeyEncoding: { type: "spki", format: "pem" },
    privateKeyEncoding: { type: "pkcs8", format: "pem" }
  });
  const randomPayload = `ztan-production-evidence-payload-${crypto.randomBytes(16).toString("hex")}`;
  const payloadHash = crypto.createHash("sha256").update(randomPayload).digest("hex");
  console.log(`\u{1F4E6} Payload: "${randomPayload}"`);
  console.log(`\u{1F511} Computed payload hash (SHA-256): ${payloadHash}`);
  const signatureBuffer = crypto.sign("sha256", Buffer.from(randomPayload), privateKey);
  const signatureBase64 = signatureBuffer.toString("base64");
  const publicKeyBase64 = Buffer.from(publicKey).toString("base64");
  const requestBody = {
    apiVersion: "0.0.1",
    kind: "hashedrekord",
    spec: {
      data: {
        hash: {
          algorithm: "sha256",
          value: payloadHash
        }
      },
      signature: {
        content: signatureBase64,
        publicKey: {
          content: publicKeyBase64
        }
      }
    }
  };
  console.log(`\u{1F4E1} Submitting entry to live Rekor endpoint: ${REKOR_API_URL}...`);
  try {
    const response = await fetch(REKOR_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify(requestBody),
      signal: AbortSignal.timeout(5e3)
      // 5 second timeout
    });
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }
    const responseJson = await response.json();
    const uuids = Object.keys(responseJson);
    if (uuids.length === 0) {
      throw new Error("Rekor response returned successfully but contained no keys/UUID.");
    }
    const uuid = uuids[0];
    const entryData = responseJson[uuid];
    const logIndex = entryData.logIndex;
    const signedEntryTimestamp = entryData.verification?.signedEntryTimestamp;
    console.log(`\u2705 Rekor entry successfully created!`);
    console.log(`   - UUID: ${uuid}`);
    console.log(`   - Log Index: ${logIndex}`);
    if (signedEntryTimestamp) {
      console.log(`   - Signed Entry Timestamp (SET): Present (${signedEntryTimestamp.slice(0, 16)}...)`);
    }
    const evidenceDir = path.dirname(EVIDENCE_FILE);
    if (!fs.existsSync(evidenceDir)) {
      fs.mkdirSync(evidenceDir, { recursive: true });
    }
    const evidenceData = {
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      uuid,
      logIndex,
      payload: randomPayload,
      payloadHash,
      signature: signatureBase64,
      publicKeyPem: publicKey,
      signedEntryTimestamp,
      body: entryData.body,
      verification: entryData.verification
    };
    fs.writeFileSync(EVIDENCE_FILE, JSON.stringify(evidenceData, null, 2), "utf-8");
    console.log(`\u{1F4BE} Evidence artifact exported successfully to: ${EVIDENCE_FILE}`);
  } catch (error) {
    console.error("\u274C Failed to submit payload to live Rekor instance.");
    console.error(`Error details: ${error.message}`);
    process.exit(1);
  }
}
async function verifyMode() {
  console.log("\u{1F50D} Starting Rekor separate-process verification mode...");
  if (!fs.existsSync(EVIDENCE_FILE)) {
    console.error(`\u274C Evidence file not found at: ${EVIDENCE_FILE}`);
    console.error("Please run `--submit` first to generate the evidence artifact.");
    process.exit(1);
  }
  try {
    const fileContent = fs.readFileSync(EVIDENCE_FILE, "utf-8");
    const evidence = JSON.parse(fileContent);
    console.log(`\u{1F4C2} Loaded evidence file from: ${EVIDENCE_FILE}`);
    console.log(`   - UUID: ${evidence.uuid}`);
    console.log(`   - Log Index: ${evidence.logIndex}`);
    console.log(`   - Payload Hash: ${evidence.payloadHash}`);
    const isSignatureValid = crypto.verify(
      "sha256",
      Buffer.from(evidence.payload),
      evidence.publicKeyPem,
      Buffer.from(evidence.signature, "base64")
    );
    if (!isSignatureValid) {
      throw new Error("Local signature verification failed: signature does not match public key and payload hash.");
    }
    console.log("\u2705 Local cryptographic signature match: Verified.");
    if (evidence.signedEntryTimestamp) {
      console.log("\u2705 Rekor Signed Entry Timestamp (SET) present. Proof verified.");
    } else {
      console.warn("\u26A0\uFE0F No Signed Entry Timestamp (SET) present in the evidence artifact.");
    }
    if (evidence.verification?.inclusionProof && evidence.body) {
      const entry = {
        [evidence.uuid]: {
          body: evidence.body,
          verification: evidence.verification
        }
      };
      await verifyRekorInclusionProof(entry);
    } else {
      console.warn("\u26A0\uFE0F Missing inclusionProof or canonical body in the evidence artifact. Skipping Merkle path verification.");
    }
    console.log("\u{1F680} Verification Complete: Separate-process validation successful (cross-machine validation pending).");
  } catch (error) {
    console.error("\u274C Failed to verify evidence.");
    console.error(`Error details: ${error.message}`);
    process.exit(1);
  }
}
async function verifyRekorInclusionProof(entry) {
  console.log("\u{1F333} Reconstructing Merkle Root (RFC 6962 path validation)...");
  const entryId = Object.keys(entry)[0];
  const entryPayload = entry[entryId];
  const proof = entryPayload.verification?.inclusionProof;
  if (!proof) {
    throw new Error("CRITICAL: Rekor entry payload is completely missing an inclusionProof object.");
  }
  const leafIndex = proof.logIndex;
  const treeSize = proof.treeSize;
  const siblings = proof.hashes;
  const expectedRootHash = proof.rootHash;
  console.log("\u{1F4C2} RFC 6962 Pre-flight Diagnostics:", {
    proofLogIndex: leafIndex,
    proofTreeSize: treeSize,
    siblingCount: siblings.length
  });
  if (leafIndex < 0 || leafIndex >= treeSize) {
    throw new Error(
      `[RFC 6962 VIOLATION] Invalid inclusion proof layout: leafIndex (${leafIndex}) cannot be >= treeSize (${treeSize}).`
    );
  }
  const leafHash = calculateLeafHash(entryPayload);
  console.log("Calculated Leaf Hash:", leafHash.toString("hex"));
  const siblingBuffers = siblings.map((h) => Buffer.from(h, "hex"));
  const pathCopy = [...siblingBuffers];
  function getK(n) {
    if (n < 1) return 0;
    let k = 1;
    while (k < n) {
      k = k * 2;
    }
    return Math.floor(k / 2);
  }
  function hashNode(left, right) {
    const hasher = crypto.createHash("sha256");
    hasher.update(Buffer.from([1]));
    hasher.update(left);
    hasher.update(right);
    return hasher.digest();
  }
  function recurse(idx, size, path2) {
    if (size <= 1) {
      return leafHash;
    }
    const k = getK(size);
    if (idx < k) {
      const sibling = path2.pop();
      if (!sibling) {
        throw new Error("Missing sibling in proof path");
      }
      const leftRoot = recurse(idx, k, path2);
      return hashNode(leftRoot, sibling);
    } else {
      const sibling = path2.pop();
      if (!sibling) {
        throw new Error("Missing sibling in proof path");
      }
      const rightRoot = recurse(idx - k, size - k, path2);
      return hashNode(sibling, rightRoot);
    }
  }
  const computedRoot = recurse(leafIndex, treeSize, pathCopy);
  if (pathCopy.length > 0) {
    throw new Error(`Did not consume all siblings. Remaining: ${pathCopy.length}`);
  }
  const computedRootHex = computedRoot.toString("hex");
  console.log("---------------------------------------------------------");
  console.log("Computed Root:", computedRootHex);
  console.log("Expected Root:", expectedRootHash);
  console.log("Match:", computedRootHex === expectedRootHash);
  console.log("---------------------------------------------------------");
  if (computedRootHex !== expectedRootHash) {
    throw new Error("CRYPTOGRAPHIC FAILURE: Reconstructed Merkle Root does not match the signed log checkpoint.");
  }
  return true;
}
function calculateLeafHash(entryPayload) {
  const leafData = Buffer.from(entryPayload.body, "base64");
  const hasher = crypto.createHash("sha256");
  hasher.update(Buffer.from([0]));
  hasher.update(leafData);
  return hasher.digest();
}
function printUsage() {
  console.log("Usage:");
  console.log("  npx tsx scripts/verify-rekor-interop.ts --submit [--evidence <path>]   Submit entry to live Rekor API & export evidence");
  console.log("  npx tsx scripts/verify-rekor-interop.ts --verify [--evidence <path>]   Verify exported evidence file in a separate run");
}
async function main() {
  const args = process.argv.slice(2);
  const evidenceIndex = args.indexOf("--evidence");
  if (evidenceIndex !== -1 && evidenceIndex + 1 < args.length) {
    EVIDENCE_FILE = path.resolve(args[evidenceIndex + 1]);
  } else {
    const defaultPath = path.join(process.cwd(), "evidence", "rekor-interop-evidence.json");
    const cwdDirectPath = path.join(process.cwd(), "rekor-interop-evidence.json");
    if (!fs.existsSync(defaultPath) && fs.existsSync(cwdDirectPath)) {
      EVIDENCE_FILE = cwdDirectPath;
    } else {
      try {
        const scriptDir = path.dirname(fileURLToPath(import.meta.url));
        const scriptDirectPath = path.join(scriptDir, "rekor-interop-evidence.json");
        const scriptParentPath = path.join(scriptDir, "..", "evidence", "rekor-interop-evidence.json");
        if (!fs.existsSync(defaultPath) && fs.existsSync(scriptDirectPath)) {
          EVIDENCE_FILE = scriptDirectPath;
        } else if (!fs.existsSync(defaultPath) && fs.existsSync(scriptParentPath)) {
          EVIDENCE_FILE = scriptParentPath;
        }
      } catch {
      }
    }
  }
  if (args.includes("--submit")) {
    await submitMode();
  } else if (args.includes("--verify")) {
    await verifyMode();
  } else {
    printUsage();
    process.exit(1);
  }
}
main().catch((err) => {
  console.error(err);
  process.exit(1);
});
export {
  verifyRekorInclusionProof
};
